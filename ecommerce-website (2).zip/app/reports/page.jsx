"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { ArrowLeft, TrendingUp, ShoppingCart, DollarSign, Package } from "lucide-react"
import { getTransactionsByPeriod, getTransactionStats, getRevenueByDate } from "@/lib/transactions"
import { formatPriceWithWords } from "@/lib/number-to-words"

export default function ReportsPage() {
  const [selectedPeriod, setSelectedPeriod] = useState("month")
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0])
  const [transactions, setTransactions] = useState([])
  const [stats, setStats] = useState(null)
  const [revenueData, setRevenueData] = useState([])

  useEffect(() => {
    const date = new Date(selectedDate)
    const filteredTransactions = getTransactionsByPeriod(selectedPeriod, date)
    setTransactions(filteredTransactions)
    setStats(getTransactionStats(filteredTransactions))
    setRevenueData(getRevenueByDate(filteredTransactions))
  }, [selectedPeriod, selectedDate])

  const getPeriodLabel = () => {
    const date = new Date(selectedDate)
    switch (selectedPeriod) {
      case "day":
        return date.toLocaleDateString("id-ID", {
          weekday: "long",
          year: "numeric",
          month: "long",
          day: "numeric",
        })
      case "week":
        const startOfWeek = new Date(date)
        startOfWeek.setDate(date.getDate() - date.getDay())
        const endOfWeek = new Date(startOfWeek)
        endOfWeek.setDate(startOfWeek.getDate() + 6)
        return `${startOfWeek.toLocaleDateString("id-ID")} - ${endOfWeek.toLocaleDateString("id-ID")}`
      case "month":
        return date.toLocaleDateString("id-ID", { year: "numeric", month: "long" })
      case "year":
        return date.getFullYear().toString()
      default:
        return ""
    }
  }

  const totalRevenueFormatted = stats ? formatPriceWithWords(stats.totalRevenue) : null
  const avgOrderValueFormatted = stats ? formatPriceWithWords(Math.round(stats.averageOrderValue)) : null

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <Link href="/admin">
                <Button variant="outline" size="sm">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Kembali
                </Button>
              </Link>
              <h1 className="text-2xl font-bold text-gray-900">Laporan Penjualan</h1>
            </div>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        {/* Filters */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Filter Laporan</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">Periode</label>
                <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="day">Harian</SelectItem>
                    <SelectItem value="week">Mingguan</SelectItem>
                    <SelectItem value="month">Bulanan</SelectItem>
                    <SelectItem value="year">Tahunan</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Tanggal</label>
                <Input type="date" value={selectedDate} onChange={(e) => setSelectedDate(e.target.value)} />
              </div>

              <div className="flex items-end">
                <div className="text-sm text-gray-600">
                  <strong>Periode yang dipilih:</strong>
                  <br />
                  {getPeriodLabel()}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Stats Cards */}
        {stats && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Pendapatan</p>
                    <p className="text-2xl font-bold text-green-600">{totalRevenueFormatted?.number}</p>
                    <p className="text-xs text-gray-500 mt-1">{totalRevenueFormatted?.words}</p>
                  </div>
                  <DollarSign className="w-8 h-8 text-green-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Pesanan</p>
                    <p className="text-2xl font-bold text-blue-600">{stats.totalOrders}</p>
                    <p className="text-xs text-gray-500 mt-1">transaksi</p>
                  </div>
                  <ShoppingCart className="w-8 h-8 text-blue-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Rata-rata Nilai Pesanan</p>
                    <p className="text-2xl font-bold text-purple-600">{avgOrderValueFormatted?.number}</p>
                    <p className="text-xs text-gray-500 mt-1">{avgOrderValueFormatted?.words}</p>
                  </div>
                  <TrendingUp className="w-8 h-8 text-purple-600" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Produk Terjual</p>
                    <p className="text-2xl font-bold text-orange-600">
                      {stats.topProducts.reduce((sum, product) => sum + product.quantity, 0)}
                    </p>
                    <p className="text-xs text-gray-500 mt-1">unit</p>
                  </div>
                  <Package className="w-8 h-8 text-orange-600" />
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Revenue Chart */}
          <Card>
            <CardHeader>
              <CardTitle>Pendapatan Harian</CardTitle>
            </CardHeader>
            <CardContent>
              {revenueData.length > 0 ? (
                <div className="space-y-4">
                  {revenueData.map((item, index) => {
                    const maxRevenue = Math.max(...revenueData.map((d) => d.revenue))
                    const percentage = (item.revenue / maxRevenue) * 100
                    const formatted = formatPriceWithWords(item.revenue)

                    return (
                      <div key={index} className="space-y-2">
                        <div className="flex justify-between items-center">
                          <span className="text-sm font-medium">{item.date}</span>
                          <div className="text-right">
                            <span className="text-sm font-bold">{formatted.number}</span>
                            <p className="text-xs text-gray-500">{formatted.words}</p>
                          </div>
                        </div>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div
                            className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                            style={{ width: `${percentage}%` }}
                          />
                        </div>
                      </div>
                    )
                  })}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">Tidak ada data untuk periode ini</p>
              )}
            </CardContent>
          </Card>

          {/* Top Products */}
          <Card>
            <CardHeader>
              <CardTitle>Produk Terlaris</CardTitle>
            </CardHeader>
            <CardContent>
              {stats?.topProducts.length > 0 ? (
                <div className="space-y-4">
                  {stats.topProducts.map((product, index) => (
                    <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-blue-600 text-white rounded-full flex items-center justify-center text-sm font-bold">
                          {index + 1}
                        </div>
                        <span className="font-medium">{product.name}</span>
                      </div>
                      <span className="text-sm font-bold text-blue-600">{product.quantity} unit</span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-gray-500 text-center py-8">Tidak ada data produk</p>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Transaction Details */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Detail Transaksi ({transactions.length})</CardTitle>
          </CardHeader>
          <CardContent>
            {transactions.length > 0 ? (
              <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>No. Invoice</TableHead>
                      <TableHead>Tanggal</TableHead>
                      <TableHead>Pelanggan</TableHead>
                      <TableHead>Items</TableHead>
                      <TableHead>Total</TableHead>
                      <TableHead>Pembayaran</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {transactions.map((transaction) => {
                      const formatted = formatPriceWithWords(transaction.total)
                      return (
                        <TableRow key={transaction.id}>
                          <TableCell className="font-medium">{transaction.orderNumber}</TableCell>
                          <TableCell>
                            {new Date(transaction.timestamp).toLocaleDateString("id-ID", {
                              year: "numeric",
                              month: "short",
                              day: "numeric",
                              hour: "2-digit",
                              minute: "2-digit",
                            })}
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-medium">{transaction.customer.name}</p>
                              <p className="text-sm text-gray-600">{transaction.customer.email}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <div className="space-y-1">
                              {transaction.items.map((item, idx) => (
                                <div key={idx} className="text-sm">
                                  {item.name} ({item.quantity}x)
                                </div>
                              ))}
                            </div>
                          </TableCell>
                          <TableCell>
                            <div>
                              <p className="font-bold">{formatted.number}</p>
                              <p className="text-xs text-gray-500">{formatted.words}</p>
                            </div>
                          </TableCell>
                          <TableCell>
                            <span className="capitalize">{transaction.customer.paymentMethod}</span>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  </TableBody>
                </Table>
              </div>
            ) : (
              <div className="text-center py-8">
                <p className="text-gray-500">Tidak ada transaksi untuk periode ini</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
