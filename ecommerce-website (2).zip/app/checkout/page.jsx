"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { ArrowLeft } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import { generateInvoicePDF } from "@/lib/pdf-generator"
import { saveTransaction } from "@/lib/transactions"
import { formatPriceWithWords } from "@/lib/number-to-words"

export default function CheckoutPage() {
  const { cartItems, getCartTotal, clearCart } = useCart()
  const [customerInfo, setCustomerInfo] = useState({
    name: "",
    email: "",
    phone: "",
    address: "",
    city: "",
    postalCode: "",
    paymentMethod: "",
  })

  const calculateDiscountedPrice = (price, discount) => {
    return price - (price * discount) / 100
  }

  const subtotal = getCartTotal()
  const tax = subtotal * 0.11
  const shipping = subtotal > 100000 ? 0 : 15000
  const total = subtotal + tax + shipping

  const handleSubmit = async (e) => {
    e.preventDefault()

    if (
      !customerInfo.name ||
      !customerInfo.email ||
      !customerInfo.phone ||
      !customerInfo.address ||
      !customerInfo.city ||
      !customerInfo.paymentMethod
    ) {
      alert("Mohon lengkapi semua informasi yang diperlukan")
      return
    }

    // Generate invoice
    const orderData = {
      orderNumber: `INV-${Date.now()}`,
      date: new Date().toLocaleDateString("id-ID"),
      customer: customerInfo,
      items: cartItems.map((item) => ({
        name: item.product.name,
        quantity: item.quantity,
        price: calculateDiscountedPrice(item.product.price, item.product.discount),
        total: calculateDiscountedPrice(item.product.price, item.product.discount) * item.quantity,
      })),
      subtotal,
      tax,
      shipping,
      total,
    }

    try {
      await generateInvoicePDF(orderData)

      // Save transaction to localStorage
      saveTransaction(orderData)

      alert("Pesanan berhasil! Invoice PDF telah diunduh.")
      clearCart()
      window.location.href = "/"
    } catch (error) {
      console.error("Error generating PDF:", error)
      alert("Terjadi kesalahan saat membuat invoice. Silakan coba lagi.")
    }
  }

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">Keranjang Kosong</h1>
          <Link href="/">
            <Button>Kembali Belanja</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <Link href="/cart">
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Kembali ke Keranjang
            </Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Customer Information */}
            <div className="space-y-6">
              <Card>
                <CardHeader>
                  <CardTitle>Informasi Pembeli</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Nama Lengkap *</label>
                    <Input
                      value={customerInfo.name}
                      onChange={(e) => setCustomerInfo({ ...customerInfo, name: e.target.value })}
                      placeholder="Masukkan nama lengkap"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Email *</label>
                    <Input
                      type="email"
                      value={customerInfo.email}
                      onChange={(e) => setCustomerInfo({ ...customerInfo, email: e.target.value })}
                      placeholder="email@example.com"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">Nomor Telepon *</label>
                    <Input
                      value={customerInfo.phone}
                      onChange={(e) => setCustomerInfo({ ...customerInfo, phone: e.target.value })}
                      placeholder="08xxxxxxxxxx"
                      required
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Alamat Pengiriman</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">Alamat Lengkap *</label>
                    <Textarea
                      value={customerInfo.address}
                      onChange={(e) => setCustomerInfo({ ...customerInfo, address: e.target.value })}
                      placeholder="Jalan, nomor rumah, RT/RW, kelurahan"
                      required
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">Kota *</label>
                      <Input
                        value={customerInfo.city}
                        onChange={(e) => setCustomerInfo({ ...customerInfo, city: e.target.value })}
                        placeholder="Nama kota"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">Kode Pos</label>
                      <Input
                        value={customerInfo.postalCode}
                        onChange={(e) => setCustomerInfo({ ...customerInfo, postalCode: e.target.value })}
                        placeholder="12345"
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Metode Pembayaran</CardTitle>
                </CardHeader>
                <CardContent>
                  <Select
                    value={customerInfo.paymentMethod}
                    onValueChange={(value) => setCustomerInfo({ ...customerInfo, paymentMethod: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Pilih metode pembayaran" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="transfer">Transfer Bank</SelectItem>
                      <SelectItem value="cod">Bayar di Tempat (COD)</SelectItem>
                      <SelectItem value="ewallet">E-Wallet</SelectItem>
                      <SelectItem value="credit">Kartu Kredit</SelectItem>
                    </SelectContent>
                  </Select>
                </CardContent>
              </Card>
            </div>

            {/* Order Summary */}
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Ringkasan Pesanan</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Items */}
                  <div className="space-y-3">
                    {cartItems.map((item) => (
                      <div key={`${item.product.id}-${item.addedAt}`} className="flex justify-between items-center">
                        <div className="flex-1">
                          <p className="font-medium">{item.product.name}</p>
                          <p className="text-sm text-gray-600">
                            {item.quantity} x Rp{" "}
                            {calculateDiscountedPrice(item.product.price, item.product.discount).toLocaleString()}
                          </p>
                        </div>
                        <span className="font-medium">
                          Rp{" "}
                          {(
                            calculateDiscountedPrice(item.product.price, item.product.discount) * item.quantity
                          ).toLocaleString()}
                        </span>
                      </div>
                    ))}
                  </div>

                  <hr />

                  {/* Totals */}
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>Rp {subtotal.toLocaleString()}</span>
                    </div>

                    <div className="flex justify-between">
                      <span>Pajak (PPN 11%)</span>
                      <span>Rp {tax.toLocaleString()}</span>
                    </div>

                    <div className="flex justify-between">
                      <span>Ongkos Kirim</span>
                      <span>
                        {shipping === 0 ? (
                          <span className="text-green-600">Gratis</span>
                        ) : (
                          `Rp ${shipping.toLocaleString()}`
                        )}
                      </span>
                    </div>

                    <hr />

                    <div className="flex justify-between font-bold text-lg">
                      <span>Total</span>
                      <div className="text-right">
                        <span>Rp {total.toLocaleString()}</span>
                        <p className="text-xs text-gray-500 font-normal">{formatPriceWithWords(total).words}</p>
                      </div>
                    </div>
                  </div>

                  <Button type="submit" className="w-full" size="lg">
                    Buat Pesanan & Unduh Invoice
                  </Button>

                  <p className="text-xs text-gray-600 text-center">
                    Dengan melanjutkan, Anda menyetujui syarat dan ketentuan yang berlaku
                  </p>
                </CardContent>
              </Card>
            </div>
          </div>
        </form>
      </div>
    </div>
  )
}
