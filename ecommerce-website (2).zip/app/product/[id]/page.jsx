"use client"

import { useState, useEffect } from "react"
import { useParams, useRouter } from "next/navigation"
import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Star, ShoppingCart } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import { getProductById, addReview } from "@/lib/products"

export default function ProductDetailPage() {
  const params = useParams()
  const router = useRouter()
  const { addToCart } = useCart()
  const [product, setProduct] = useState(null)
  const [quantity, setQuantity] = useState(1)
  const [newReview, setNewReview] = useState({ rating: 5, comment: "", author: "" })

  useEffect(() => {
    if (params.id) {
      const foundProduct = getProductById(params.id)
      setProduct(foundProduct)
    }
  }, [params.id])

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <p>Produk tidak ditemukan</p>
      </div>
    )
  }

  const calculateDiscountedPrice = (price, discount) => {
    return price - (price * discount) / 100
  }

  const renderStars = (rating, interactive = false, onRatingChange) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${interactive ? "cursor-pointer" : ""} ${
          i < rating ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
        }`}
        onClick={interactive && onRatingChange ? () => onRatingChange(i + 1) : undefined}
      />
    ))
  }

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addToCart(product)
    }
    router.push("/cart")
  }

  const handleAddReview = () => {
    if (newReview.author.trim() && newReview.comment.trim()) {
      const review = {
        id: Date.now().toString(),
        author: newReview.author,
        rating: newReview.rating,
        comment: newReview.comment,
        date: new Date().toLocaleDateString("id-ID"),
      }

      addReview(product.id, review)
      setProduct(getProductById(product.id))
      setNewReview({ rating: 5, comment: "", author: "" })
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <Link href="/">
            <Button variant="outline" size="sm">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Kembali
            </Button>
          </Link>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Product Image */}
          <div className="relative">
            <Image
              src={product.image || "/placeholder.svg"}
              alt={product.name}
              width={600}
              height={400}
              className="w-full h-96 object-cover rounded-lg"
            />
            {product.discount > 0 && (
              <Badge className="absolute top-4 right-4 bg-red-500 text-lg px-3 py-1">-{product.discount}%</Badge>
            )}
          </div>

          {/* Product Info */}
          <div>
            <div className="flex items-center gap-1 mb-4">
              {renderStars(product.rating)}
              <span className="text-gray-600 ml-2">({product.reviewCount} ulasan)</span>
            </div>

            <h1 className="text-3xl font-bold mb-4">{product.name}</h1>
            <p className="text-gray-600 mb-6">{product.description}</p>

            <div className="mb-6">
              <Badge variant="outline" className="mb-4">
                {product.category}
              </Badge>
              <div className="flex items-center gap-3 mb-4">
                {product.discount > 0 ? (
                  <>
                    <span className="text-3xl font-bold text-green-600">
                      Rp {calculateDiscountedPrice(product.price, product.discount).toLocaleString()}
                    </span>
                    <span className="text-xl text-gray-500 line-through">Rp {product.price.toLocaleString()}</span>
                  </>
                ) : (
                  <span className="text-3xl font-bold text-gray-900">Rp {product.price.toLocaleString()}</span>
                )}
              </div>
              <p className="text-lg text-gray-600">Stok tersedia: {product.stock}</p>
            </div>

            {/* Quantity and Add to Cart */}
            <div className="flex items-center gap-4 mb-6">
              <div className="flex items-center gap-2">
                <label htmlFor="quantity" className="text-sm font-medium">
                  Jumlah:
                </label>
                <Input
                  id="quantity"
                  type="number"
                  min="1"
                  max={product.stock}
                  value={quantity}
                  onChange={(e) =>
                    setQuantity(Math.max(1, Math.min(product.stock, Number.parseInt(e.target.value) || 1)))
                  }
                  className="w-20"
                />
              </div>
              <Button onClick={handleAddToCart} disabled={product.stock === 0} className="flex-1">
                <ShoppingCart className="w-4 h-4 mr-2" />
                {product.stock === 0 ? "Stok Habis" : "Tambah ke Keranjang"}
              </Button>
            </div>
          </div>
        </div>

        {/* Reviews Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Existing Reviews */}
          <Card>
            <CardHeader>
              <CardTitle>Ulasan Produk ({product.reviews?.length || 0})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {product.reviews && product.reviews.length > 0 ? (
                  product.reviews.map((review) => (
                    <div key={review.id} className="border-b pb-4 last:border-b-0">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium">{review.author}</span>
                        <span className="text-sm text-gray-500">{review.date}</span>
                      </div>
                      <div className="flex items-center gap-1 mb-2">{renderStars(review.rating)}</div>
                      <p className="text-gray-700">{review.comment}</p>
                    </div>
                  ))
                ) : (
                  <p className="text-gray-500">Belum ada ulasan untuk produk ini.</p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Add Review */}
          <Card>
            <CardHeader>
              <CardTitle>Tambah Ulasan</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Nama</label>
                <Input
                  value={newReview.author}
                  onChange={(e) => setNewReview({ ...newReview, author: e.target.value })}
                  placeholder="Masukkan nama Anda"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Rating</label>
                <div className="flex items-center gap-1">
                  {renderStars(newReview.rating, true, (rating) => setNewReview({ ...newReview, rating }))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">Komentar</label>
                <Textarea
                  value={newReview.comment}
                  onChange={(e) => setNewReview({ ...newReview, comment: e.target.value })}
                  placeholder="Tulis ulasan Anda..."
                  rows={4}
                />
              </div>

              <Button onClick={handleAddReview} className="w-full">
                Kirim Ulasan
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
