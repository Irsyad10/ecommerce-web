"use client"

import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Plus, Minus, Trash2 } from "lucide-react"
import { useCart } from "@/lib/cart-context"
import { formatPriceWithWords } from "@/lib/number-to-words"

export default function CartPage() {
  const { cartItems, updateQuantity, removeFromCart, getCartTotal, clearCart } = useCart()

  const calculateDiscountedPrice = (price, discount) => {
    return price - (price * discount) / 100
  }

  const subtotal = getCartTotal()
  const tax = subtotal * 0.11 // PPN 11%
  const shipping = subtotal > 100000 ? 0 : 15000 // Gratis ongkir di atas 100k
  const total = subtotal + tax + shipping

  if (cartItems.length === 0) {
    return (
      <div className="min-h-screen bg-gray-50">
        <header className="bg-white shadow-sm border-b">
          <div className="container mx-auto px-4 py-4">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Kembali Belanja
              </Button>
            </Link>
          </div>
        </header>

        <div className="container mx-auto px-4 py-16 text-center">
          <h1 className="text-2xl font-bold mb-4">Keranjang Kosong</h1>
          <p className="text-gray-600 mb-8">Belum ada produk di keranjang Anda</p>
          <Link href="/">
            <Button>Mulai Belanja</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Lanjut Belanja
              </Button>
            </Link>
            <h1 className="text-2xl font-bold">Keranjang Belanja</h1>
            <Button variant="outline" onClick={clearCart}>
              Kosongkan Keranjang
            </Button>
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Produk ({cartItems.length})</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {cartItems.map((item) => (
                    <div
                      key={`${item.product.id}-${item.addedAt}`}
                      className="flex items-center gap-4 p-4 border rounded-lg"
                    >
                      <Image
                        src={item.product.image || "/placeholder.svg"}
                        alt={item.product.name}
                        width={80}
                        height={80}
                        className="w-20 h-20 object-cover rounded"
                      />

                      <div className="flex-1">
                        <h3 className="font-medium">{item.product.name}</h3>
                        <p className="text-sm text-gray-600">{item.product.category}</p>
                        <div className="flex items-center gap-2 mt-1">
                          {item.product.discount > 0 ? (
                            <>
                              <span className="font-bold text-green-600">
                                Rp{" "}
                                {calculateDiscountedPrice(item.product.price, item.product.discount).toLocaleString()}
                              </span>
                              <span className="text-sm text-gray-500 line-through">
                                Rp {item.product.price.toLocaleString()}
                              </span>
                            </>
                          ) : (
                            <span className="font-bold">Rp {item.product.price.toLocaleString()}</span>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(item.product.id, item.addedAt, Math.max(0, item.quantity - 1))}
                        >
                          <Minus className="w-4 h-4" />
                        </Button>
                        <Input
                          type="number"
                          value={item.quantity}
                          onChange={(e) =>
                            updateQuantity(
                              item.product.id,
                              item.addedAt,
                              Math.max(0, Number.parseInt(e.target.value) || 0),
                            )
                          }
                          className="w-16 text-center"
                          min="0"
                        />
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => updateQuantity(item.product.id, item.addedAt, item.quantity + 1)}
                        >
                          <Plus className="w-4 h-4" />
                        </Button>
                      </div>

                      <div className="text-right">
                        <p className="font-bold">
                          Rp{" "}
                          {(
                            calculateDiscountedPrice(item.product.price, item.product.discount) * item.quantity
                          ).toLocaleString()}
                        </p>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => removeFromCart(item.product.id, item.addedAt)}
                          className="mt-2"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Order Summary */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle>Ringkasan Pesanan</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>Rp {subtotal.toLocaleString()}</span>
                </div>

                <div className="flex justify-between">
                  <span>Pajak (PPN 11%)</span>
                  <span>Rp {tax.toLocaleString()}</span>
                </div>

                <div className="flex justify-between">
                  <span>Ongkos Kirim</span>
                  <span>
                    {shipping === 0 ? (
                      <span className="text-green-600">Gratis</span>
                    ) : (
                      `Rp ${shipping.toLocaleString()}`
                    )}
                  </span>
                </div>

                {subtotal < 100000 && (
                  <p className="text-sm text-gray-600">
                    Belanja Rp {(100000 - subtotal).toLocaleString()} lagi untuk gratis ongkir!
                  </p>
                )}

                <hr />

                <div className="flex justify-between font-bold text-lg">
                  <span>Total</span>
                  <div className="text-right">
                    <span>Rp {total.toLocaleString()}</span>
                    <p className="text-xs text-gray-500 font-normal">{formatPriceWithWords(total).words}</p>
                  </div>
                </div>

                <Link href="/checkout" className="block">
                  <Button className="w-full" size="lg">
                    Checkout
                  </Button>
                </Link>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  )
}
